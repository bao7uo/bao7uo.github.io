Telerik UI for ASP.NET AJAX
Trial version:
2016.2.504.40